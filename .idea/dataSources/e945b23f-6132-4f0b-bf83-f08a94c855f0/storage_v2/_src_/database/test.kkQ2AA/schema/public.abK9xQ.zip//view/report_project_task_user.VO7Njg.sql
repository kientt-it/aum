create view report_project_task_user
            (nbr, id, task_id, active, create_date, date_assign, date_end, date_last_stage_update, date_deadline,
             project_id, priority, name, company_id, partner_id, parent_id, ancestor_id, stage_id, is_closed, state,
             milestone_id, milestone_reached, milestone_deadline, rating_last_value, rating_avg, working_days_close,
             working_days_open, working_hours_open, working_hours_close, delay_endings_days, planned_date_begin,
             planned_date_end, sale_line_id, sale_order_id)
as
SELECT (SELECT 1)                                       AS nbr,
       t.id,
       t.id                                             AS task_id,
       t.active,
       t.create_date,
       t.date_assign,
       t.date_end,
       t.date_last_stage_update,
       t.date_deadline,
       t.project_id,
       t.priority,
       t.name,
       t.company_id,
       t.partner_id,
       t.parent_id,
       t.ancestor_id,
       t.stage_id,
       t.is_closed,
       t.kanban_state                                   AS state,
       t.milestone_id,
       pm.is_reached                                    AS milestone_reached,
       pm.deadline                                      AS milestone_deadline,
       NULLIF(t.rating_last_value, 0::double precision) AS rating_last_value,
       avg(rt.rating)                                   AS rating_avg,
       t.working_days_close,
       t.working_days_open,
       t.working_hours_open,
       t.working_hours_close,
       EXTRACT(epoch FROM t.date_deadline::timestamp without time zone - (now() AT TIME ZONE 'UTC'::text)) /
       (3600 * 24)::numeric                             AS delay_endings_days,
       t.planned_date_begin,
       t.planned_date_end,
       t.sale_line_id,
       t.sale_order_id
FROM project_task t
         LEFT JOIN rating_rating rt
                   ON rt.res_id = t.id AND rt.res_model::text = 'project.task'::text AND rt.consumed = true AND
                      rt.rating >= 1::double precision
         LEFT JOIN project_milestone pm ON pm.id = t.milestone_id
WHERE t.project_id IS NOT NULL
GROUP BY t.id, t.active, t.create_date, t.date_assign, t.date_end, t.date_last_stage_update, t.date_deadline,
         t.project_id, t.ancestor_id, t.priority, t.name, t.company_id, t.partner_id, t.parent_id, t.stage_id,
         t.is_closed, t.kanban_state, t.rating_last_value, t.working_days_close, t.working_days_open,
         t.working_hours_open, t.working_hours_close, t.milestone_id, pm.is_reached, pm.deadline, t.planned_date_begin,
         t.planned_date_end, t.sale_line_id, t.sale_order_id;

alter table report_project_task_user
    owner to odoo_user;

