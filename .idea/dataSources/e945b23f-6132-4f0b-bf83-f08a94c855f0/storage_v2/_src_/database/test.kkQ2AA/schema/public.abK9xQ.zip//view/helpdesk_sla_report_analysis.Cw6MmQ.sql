create view helpdesk_sla_report_analysis
            (id, ticket_id, create_date, team_id, ticket_stage_id, ticket_type_id, user_id, partner_id, company_id,
             priority, ticket_deadline, ticket_close_hours, ticket_assignation_hours, close_date, ticket_closed,
             sla_stage_id, sla_deadline, sla_reached_datetime, sla_id, sla_exceeded_hours, sla_status_fail,
             sla_status_successful, sla_status_failed, sla_status_ongoing, successful_sla_rate, failed_sla_rate,
             ongoing_sla_rate, sla_status, sale_order_id)
as
SELECT DISTINCT t.id,
                t.id                                                                                 AS ticket_id,
                t.create_date,
                t.team_id,
                t.stage_id                                                                           AS ticket_stage_id,
                t.ticket_type_id,
                t.user_id,
                t.partner_id,
                t.company_id,
                t.priority,
                t.sla_deadline                                                                       AS ticket_deadline,
                t.close_hours                                                                        AS ticket_close_hours,
                t.assign_hours                                                                       AS ticket_assignation_hours,
                t.close_date,
                stage.fold                                                                           AS ticket_closed,
                sla.stage_id                                                                         AS sla_stage_id,
                sla_s.deadline                                                                       AS sla_deadline,
                sla_s.reached_datetime                                                               AS sla_reached_datetime,
                sla.id                                                                               AS sla_id,
                sla_s.exceeded_hours                                                                 AS sla_exceeded_hours,
                sla_s.reached_datetime >= sla_s.deadline OR
                sla_s.reached_datetime IS NULL AND sla_s.deadline < (now() AT TIME ZONE 'UTC'::text) AS sla_status_fail,
                CASE
                    WHEN sla_s.reached_datetime IS NOT NULL AND
                         (sla_s.deadline IS NULL OR sla_s.reached_datetime < sla_s.deadline) THEN 1
                    ELSE 0
                    END                                                                              AS sla_status_successful,
                CASE
                    WHEN sla_s.reached_datetime IS NOT NULL AND sla_s.deadline IS NOT NULL AND
                         sla_s.reached_datetime >= sla_s.deadline THEN 1
                    WHEN sla_s.reached_datetime IS NULL AND sla_s.deadline IS NOT NULL AND
                         sla_s.deadline < (now() AT TIME ZONE 'UTC'::text) THEN 1
                    ELSE 0
                    END                                                                              AS sla_status_failed,
                CASE
                    WHEN sla_s.reached_datetime IS NULL AND
                         (sla_s.deadline IS NULL OR sla_s.deadline > (now() AT TIME ZONE 'UTC'::text)) THEN 1
                    ELSE 0
                    END                                                                              AS sla_status_ongoing,
                CASE
                    WHEN sla_s.reached_datetime IS NOT NULL AND
                         (sla_s.deadline IS NULL OR sla_s.reached_datetime < sla_s.deadline) THEN 1
                    ELSE 0
                    END                                                                              AS successful_sla_rate,
                CASE
                    WHEN sla_s.reached_datetime IS NOT NULL AND sla_s.deadline IS NOT NULL AND
                         sla_s.reached_datetime >= sla_s.deadline THEN 1
                    WHEN sla_s.reached_datetime IS NULL AND sla_s.deadline IS NOT NULL AND
                         sla_s.deadline < (now() AT TIME ZONE 'UTC'::text) THEN 1
                    ELSE 0
                    END                                                                              AS failed_sla_rate,
                CASE
                    WHEN sla_s.reached_datetime IS NULL AND
                         (sla_s.deadline IS NULL OR sla_s.deadline > (now() AT TIME ZONE 'UTC'::text)) THEN 1
                    ELSE 0
                    END                                                                              AS ongoing_sla_rate,
                CASE
                    WHEN sla_s.reached_datetime IS NOT NULL AND
                         (sla_s.deadline IS NULL OR sla_s.reached_datetime < sla_s.deadline) THEN 'reached'::text
                    WHEN sla_s.reached_datetime IS NOT NULL AND sla_s.deadline IS NOT NULL AND
                         sla_s.reached_datetime >= sla_s.deadline OR
                         sla_s.reached_datetime IS NULL AND sla_s.deadline IS NOT NULL AND
                         sla_s.deadline < (now() AT TIME ZONE 'UTC'::text) THEN 'failed'::text
                    WHEN sla_s.reached_datetime IS NULL AND
                         (sla_s.deadline IS NULL OR sla_s.deadline > (now() AT TIME ZONE 'UTC'::text)) THEN 'ongoing'::text
                    ELSE NULL::text
                    END                                                                              AS sla_status,
                t.sale_order_id
FROM helpdesk_ticket t
         LEFT JOIN helpdesk_stage stage ON t.stage_id = stage.id
         RIGHT JOIN helpdesk_sla_status sla_s ON t.id = sla_s.ticket_id
         LEFT JOIN helpdesk_sla sla ON sla.id = sla_s.sla_id
WHERE t.active = true
ORDER BY t.id, sla.stage_id;

alter table helpdesk_sla_report_analysis
    owner to odoo_user;

