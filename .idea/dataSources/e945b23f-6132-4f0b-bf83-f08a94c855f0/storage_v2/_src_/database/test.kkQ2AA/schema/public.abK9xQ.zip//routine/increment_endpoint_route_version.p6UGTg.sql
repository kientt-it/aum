create function increment_endpoint_route_version() returns trigger
    language plpgsql
as
$$
                BEGIN
                  PERFORM nextval('endpoint_route_version');
                  RETURN NEW;
                END;
                $$;

alter function increment_endpoint_route_version() owner to odoo_user;

