create view helpdesk_ticket_report_analysis
            (id, ticket_id, create_date, priority, user_id, partner_id, ticket_type_id, ticket_stage_id,
             ticket_deadline, ticket_deadline_hours, ticket_close_hours, ticket_open_hours, ticket_assignation_hours,
             close_date, assign_date, rating_last_value, active, team_id, company_id, kanban_state,
             first_response_hours, avg_response_hours, sale_order_id)
as
SELECT id,
       id                                                                                                      AS ticket_id,
       create_date,
       priority,
       user_id,
       partner_id,
       ticket_type_id,
       stage_id                                                                                                AS ticket_stage_id,
       sla_deadline                                                                                            AS ticket_deadline,
       NULLIF(sla_deadline_hours, 0::double precision)                                                         AS ticket_deadline_hours,
       NULLIF(close_hours, 0)                                                                                  AS ticket_close_hours,
       EXTRACT(hour FROM COALESCE(assign_date::timestamp with time zone, now()) -
                         create_date::timestamp with time zone)                                                AS ticket_open_hours,
       NULLIF(assign_hours, 0)                                                                                 AS ticket_assignation_hours,
       close_date,
       assign_date,
       NULLIF(rating_last_value, 0::double precision)                                                          AS rating_last_value,
       active,
       team_id,
       company_id,
       kanban_state,
       NULLIF(first_response_hours, 0::double precision)                                                       AS first_response_hours,
       NULLIF(avg_response_hours, 0::double precision)                                                         AS avg_response_hours,
       sale_order_id
FROM helpdesk_ticket t;

alter table helpdesk_ticket_report_analysis
    owner to odoo_user;

