create function endpoint_route_set_timestamp() returns trigger
    language plpgsql
as
$$
            BEGIN
                NEW.updated_at = NOW();
                RETURN NEW;
            END;
            $$;

alter function endpoint_route_set_timestamp() owner to odoo_user;

