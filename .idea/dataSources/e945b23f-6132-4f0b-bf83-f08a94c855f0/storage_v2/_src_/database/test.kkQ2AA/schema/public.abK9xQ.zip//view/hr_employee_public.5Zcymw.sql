create view hr_employee_public
            (name, active, color, department_id, job_id, job_title, company_id, address_id, work_phone, mobile_phone,
             work_email, work_contact_id, work_location_id, user_id, resource_id, resource_calendar_id, parent_id,
             coach_id, employee_type, create_date, id, create_uid, write_uid, write_date)
as
SELECT name,
       active,
       color,
       department_id,
       job_id,
       job_title,
       company_id,
       address_id,
       work_phone,
       mobile_phone,
       work_email,
       work_contact_id,
       work_location_id,
       user_id,
       resource_id,
       resource_calendar_id,
       parent_id,
       coach_id,
       employee_type,
       create_date,
       id,
       create_uid,
       write_uid,
       write_date
FROM hr_employee emp;

alter table hr_employee_public
    owner to odoo_user;

