create view planning_analysis_report
            (id, allocated_hours, allocated_percentage, company_id, department_id, employee_id, end_datetime, job_title,
             manager_id, name, publication_warning, resource_id, resource_type, role_id, recurrency_id, start_datetime,
             state, user_id, working_days_count, project_id, effective_hours, percentage_hours, remaining_hours,
             allocated_hours_cost, effective_hours_cost, sale_order_id, sale_line_id, billable_allocated_hours,
             non_billable_allocated_hours)
as
SELECT id,
       allocated_hours,
       allocated_percentage,
       company_id,
       department_id,
       employee_id,
       end_datetime,
       job_title,
       manager_id,
       name,
       publication_warning,
       resource_id,
       resource_type,
       role_id,
       recurrency_id,
       start_datetime,
       state,
       user_id,
       working_days_count,
       project_id,
       effective_hours,
       percentage_hours,
       remaining_hours,
       allocated_hours_cost,
       effective_hours_cost,
       sale_order_id,
       sale_line_id,
       billable_allocated_hours,
       allocated_hours - billable_allocated_hours AS non_billable_allocated_hours
FROM (SELECT s_1.id,
             s_1.allocated_hours,
             s_1.allocated_percentage,
             s_1.company_id,
             s_1.department_id,
             s_1.employee_id,
             s_1.end_datetime,
             e.job_title,
             s_1.manager_id,
             s_1.name,
             s_1.publication_warning,
             s_1.resource_id,
             r.resource_type,
             s_1.role_id,
             s_1.recurrency_id,
             s_1.start_datetime,
             s_1.state,
             s_1.user_id,
             s_1.working_days_count,
             s_1.project_id,
             s_1.effective_hours,
             s_1.percentage_hours,
             s_1.allocated_hours - s_1.effective_hours             AS remaining_hours,
             s_1.allocated_hours * e.hourly_cost::double precision AS allocated_hours_cost,
             s_1.effective_hours * e.hourly_cost::double precision AS effective_hours_cost,
             s_1.sale_order_id,
             s_1.sale_line_id,
             CASE
                 WHEN s_1.sale_line_id IS NULL THEN 0::double precision
                 ELSE s_1.allocated_hours
                 END                                               AS billable_allocated_hours
      FROM planning_slot s_1
               LEFT JOIN hr_employee e ON e.id = s_1.employee_id
               LEFT JOIN resource_resource r ON r.id = s_1.resource_id
      WHERE s_1.start_datetime IS NOT NULL
      GROUP BY s_1.id, s_1.allocated_hours, s_1.allocated_percentage, s_1.company_id, s_1.department_id,
               s_1.employee_id, s_1.end_datetime, e.job_title, s_1.manager_id, s_1.name, s_1.publication_warning,
               s_1.resource_id, r.resource_type, s_1.role_id, s_1.recurrency_id, s_1.start_datetime, s_1.state,
               s_1.user_id, s_1.working_days_count, s_1.project_id, s_1.effective_hours, e.hourly_cost,
               s_1.sale_order_id, s_1.sale_line_id) s;

alter table planning_analysis_report
    owner to odoo_user;

