create view hr_payroll_report
            (id, count, count_work, count_work_hours, count_leave, count_leave_unpaid, count_unforeseen_absence,
             leave_basic_wage, name, date_from, date_to, employee_id, department_id, master_department_id, job_id,
             work_entry_source, company_id, work_code, work_type, number_of_days, number_of_hours, net_wage, basic_wage,
             gross_wage)
as
SELECT p.id,
       CASE
           WHEN wd.id = min_id.min_line THEN 1
           ELSE 0
           END AS count,
       CASE
           WHEN wet.is_leave THEN 0::double precision
           ELSE wd.number_of_days
           END AS count_work,
       CASE
           WHEN wet.is_leave THEN 0::double precision
           ELSE wd.number_of_hours
           END AS count_work_hours,
       CASE
           WHEN wet.is_leave AND wd.amount <> 0::numeric THEN wd.number_of_days
           ELSE 0::double precision
           END AS count_leave,
       CASE
           WHEN wet.is_leave AND wd.amount = 0::numeric THEN wd.number_of_days
           ELSE 0::double precision
           END AS count_leave_unpaid,
       CASE
           WHEN wet.is_unforeseen THEN wd.number_of_days
           ELSE 0::double precision
           END AS count_unforeseen_absence,
       CASE
           WHEN wet.is_leave THEN wd.amount
           ELSE 0::numeric
           END AS leave_basic_wage,
       p.name,
       p.date_from,
       p.date_to,
       e.id    AS employee_id,
       e.department_id,
       d.master_department_id,
       c.job_id,
       c.work_entry_source,
       e.company_id,
       wet.id  AS work_code,
       CASE
           WHEN wet.is_leave IS NOT TRUE THEN '1'::text
           WHEN wd.amount = 0::numeric THEN '3'::text
           ELSE '2'::text
           END AS work_type,
       wd.number_of_days,
       wd.number_of_hours,
       CASE
           WHEN wd.id = min_id.min_line THEN pln.total
           ELSE 0::numeric
           END AS net_wage,
       CASE
           WHEN wd.id = min_id.min_line THEN plb.total
           ELSE 0::numeric
           END AS basic_wage,
       CASE
           WHEN wd.id = min_id.min_line THEN plg.total
           ELSE 0::numeric
           END AS gross_wage
FROM (SELECT hr_payslip.id,
             hr_payslip.message_main_attachment_id,
             hr_payslip.struct_id,
             hr_payslip.employee_id,
             hr_payslip.department_id,
             hr_payslip.job_id,
             hr_payslip.company_id,
             hr_payslip.contract_id,
             hr_payslip.payslip_run_id,
             hr_payslip.normal_wage,
             hr_payslip.create_uid,
             hr_payslip.write_uid,
             hr_payslip.email_cc,
             hr_payslip.name,
             hr_payslip.number,
             hr_payslip.state,
             hr_payslip.warning_message,
             hr_payslip.date_from,
             hr_payslip.date_to,
             hr_payslip.compute_date,
             hr_payslip.note,
             hr_payslip.basic_wage,
             hr_payslip.net_wage,
             hr_payslip.paid,
             hr_payslip.credit_note,
             hr_payslip.has_negative_net_to_report,
             hr_payslip.edited,
             hr_payslip.queued_for_pdf,
             hr_payslip.create_date,
             hr_payslip.write_date,
             hr_payslip.sum_worked_hours,
             hr_payslip.th_send_mail,
             hr_payslip.th_month_days,
             hr_payslip.move_id,
             hr_payslip.date
      FROM hr_payslip
      WHERE hr_payslip.state::text = ANY (ARRAY ['done'::character varying::text, 'paid'::character varying::text])) p
         LEFT JOIN hr_employee e ON p.employee_id = e.id
         LEFT JOIN hr_payslip_worked_days wd ON wd.payslip_id = p.id
         LEFT JOIN hr_work_entry_type wet ON wet.id = wd.work_entry_type_id
         LEFT JOIN (SELECT hr_payslip_worked_days.payslip_id,
                           min(hr_payslip_worked_days.id) AS min_line
                    FROM hr_payslip_worked_days
                    GROUP BY hr_payslip_worked_days.payslip_id) min_id ON min_id.payslip_id = p.id
         LEFT JOIN hr_payslip_line pln ON pln.slip_id = p.id AND pln.code::text = 'NET'::text
         LEFT JOIN hr_payslip_line plb ON plb.slip_id = p.id AND plb.code::text = 'BASIC'::text
         LEFT JOIN hr_payslip_line plg ON plg.slip_id = p.id AND plg.code::text = 'GROSS'::text
         LEFT JOIN hr_contract c ON p.contract_id = c.id
         LEFT JOIN hr_department d ON e.department_id = d.id
GROUP BY e.id, e.department_id, d.master_department_id, e.company_id, wd.id, wet.id, p.id, p.name, p.date_from,
         p.date_to, pln.total, plb.total, plg.total, min_id.min_line, c.id;

alter table hr_payroll_report
    owner to odoo_user;

