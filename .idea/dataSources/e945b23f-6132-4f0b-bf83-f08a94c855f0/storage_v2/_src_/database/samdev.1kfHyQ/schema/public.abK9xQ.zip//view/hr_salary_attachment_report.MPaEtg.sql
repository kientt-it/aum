create view hr_salary_attachment_report
            (id, payslip_id, employee_id, company_id, payslip_start_date, payslip_end_date, attachment_amount,
             assignment_amount, child_support_amount)
as
SELECT row_number() OVER () AS id,
       p.id                 AS payslip_id,
       p.employee_id,
       p.company_id,
       p.date_from          AS payslip_start_date,
       p.date_to            AS payslip_end_date,
       CASE
           WHEN pl.code::text = 'ATTACH_SALARY'::text THEN pl.amount
           ELSE NULL::numeric
           END              AS attachment_amount,
       CASE
           WHEN pl.code::text = 'ASSIG_SALARY'::text THEN pl.amount
           ELSE NULL::numeric
           END              AS assignment_amount,
       CASE
           WHEN pl.code::text = 'CHILD_SUPPORT'::text THEN pl.amount
           ELSE NULL::numeric
           END              AS child_support_amount
FROM hr_payslip p
         LEFT JOIN hr_payslip_line pl ON pl.slip_id = p.id
WHERE (pl.code::text = ANY
       (ARRAY ['ATTACH_SALARY'::character varying::text, 'ASSIG_SALARY'::character varying::text, 'CHILD_SUPPORT'::character varying::text]))
  AND p.state::text = 'paid'::text;

alter table hr_salary_attachment_report
    owner to odoo_user;

