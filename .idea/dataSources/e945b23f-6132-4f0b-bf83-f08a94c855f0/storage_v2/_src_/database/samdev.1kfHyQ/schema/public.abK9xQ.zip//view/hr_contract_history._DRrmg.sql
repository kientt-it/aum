create view hr_contract_history
            (id, employee_id, active_employee, contract_id, is_under_contract, date_hired, name, date_start, date_end,
             department_id, structure_type_id, hr_responsible_id, job_id, state, resource_calendar_id, wage, company_id,
             contract_type_id, time_credit, work_time_rate, standard_calendar_id, analytic_account_id)
as
WITH contract_information AS (SELECT DISTINCT contract_1.employee_id,
                                              contract_1.company_id,
                                              first_value(contract_1.id) OVER w_partition AS id,
                                              max(
                                              CASE
                                                  WHEN contract_1.state::text = 'open'::text THEN 1
                                                  WHEN contract_1.state::text = 'draft'::text AND
                                                       contract_1.kanban_state::text = 'done'::text THEN 1
                                                  ELSE 0
                                                  END) OVER w_partition                   AS is_under_contract
                              FROM hr_contract contract_1
                              WHERE contract_1.active = true
                              WINDOW w_partition AS ( PARTITION BY contract_1.employee_id, contract_1.company_id
                                      ORDER BY (
                                          CASE
                                              WHEN contract_1.state::text = 'open'::text THEN 0
                                              WHEN contract_1.state::text = 'draft'::text THEN 1
                                              WHEN contract_1.state::text = 'close'::text THEN 2
                                              WHEN contract_1.state::text = 'cancel'::text THEN 3
                                              ELSE 4
                                              END), contract_1.date_start DESC
                                      RANGE BETWEEN UNBOUNDED PRECEDING AND UNBOUNDED FOLLOWING ))
SELECT DISTINCT employee.id,
                employee.id                                     AS employee_id,
                employee.active                                 AS active_employee,
                contract.id                                     AS contract_id,
                contract_information.is_under_contract::boolean AS is_under_contract,
                employee.first_contract_date                    AS date_hired,
                contract.name,
                contract.date_start,
                contract.date_end,
                contract.department_id,
                contract.structure_type_id,
                contract.hr_responsible_id,
                contract.job_id,
                contract.state,
                contract.resource_calendar_id,
                contract.wage,
                contract.company_id,
                contract.contract_type_id,
                contract.time_credit,
                contract.work_time_rate,
                contract.standard_calendar_id,
                contract.analytic_account_id
FROM hr_contract contract
         JOIN contract_information ON contract.id = contract_information.id
         RIGHT JOIN hr_employee employee
                    ON contract_information.employee_id = employee.id AND contract.company_id = employee.company_id
WHERE employee.employee_type::text = ANY
      (ARRAY ['employee'::character varying::text, 'student'::character varying::text, 'trainee'::character varying::text]);

alter table hr_contract_history
    owner to odoo_user;

