create view hr_appraisal_report (id, create_date, employee_id, department_id, deadline, final_interview, state) as
SELECT min(a.id)           AS id,
       date(a.create_date) AS create_date,
       a.employee_id,
       e.department_id,
       a.date_close        AS deadline,
       CASE
           WHEN min(ce.start) >= timezone('UTC'::text, now()) THEN min(ce.start)
           ELSE max(ce.start)
           END             AS final_interview,
       a.state
FROM hr_appraisal a
         LEFT JOIN hr_employee e ON e.id = a.employee_id
         LEFT JOIN calendar_event ce ON ce.res_id = a.id AND ce.res_model::text = 'hr.appraisal'::text
GROUP BY a.id, a.create_date, a.state, a.employee_id, a.date_close, e.department_id;

alter table hr_appraisal_report
    owner to odoo_user;

