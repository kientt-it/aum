create view timesheets_analysis_report
            (id, name, user_id, project_id, task_id, ancestor_task_id, employee_id, manager_id, company_id,
             department_id, currency_id, date, amount, unit_amount, validated, is_timesheet, order_id, so_line,
             timesheet_invoice_type, timesheet_invoice_id, timesheet_revenues, billable_time, margin, non_billable_time)
as
SELECT id,
       name,
       user_id,
       project_id,
       task_id,
       ancestor_task_id,
       employee_id,
       manager_id,
       company_id,
       department_id,
       currency_id,
       date,
       amount,
       unit_amount,
       validated,
       is_timesheet,
       order_id,
       so_line,
       timesheet_invoice_type,
       timesheet_invoice_id,
       timesheet_revenues,
       billable_time,
       timesheet_revenues + amount::double precision AS margin,
       unit_amount - billable_time                   AS non_billable_time
FROM (SELECT a_1.id,
             a_1.name,
             a_1.user_id,
             a_1.project_id,
             a_1.task_id,
             a_1.ancestor_task_id,
             a_1.employee_id,
             a_1.manager_id,
             a_1.company_id,
             a_1.department_id,
             a_1.currency_id,
             a_1.date,
             a_1.amount,
             a_1.unit_amount,
             a_1.validated,
             a_1.project_id IS NOT NULL AS is_timesheet,
             a_1.order_id,
             a_1.so_line,
             a_1.timesheet_invoice_type,
             a_1.timesheet_invoice_id,
             CASE
                 WHEN a_1.order_id IS NULL THEN 0::double precision
                 ELSE a_1.unit_amount * sol.price_unit::double precision * sol_product_uom.factor::double precision /
                      a_product_uom.factor::double precision
                 END                    AS timesheet_revenues,
             CASE
                 WHEN a_1.order_id IS NULL THEN 0::double precision
                 ELSE a_1.unit_amount
                 END                    AS billable_time
      FROM account_analytic_line a_1
               LEFT JOIN sale_order_line sol ON a_1.so_line = sol.id
               LEFT JOIN uom_uom sol_product_uom ON sol_product_uom.id = sol.product_uom
               JOIN uom_uom a_product_uom ON a_product_uom.id = a_1.product_uom_id
      WHERE a_1.project_id IS NOT NULL) a;

alter table timesheets_analysis_report
    owner to odoo_user;

