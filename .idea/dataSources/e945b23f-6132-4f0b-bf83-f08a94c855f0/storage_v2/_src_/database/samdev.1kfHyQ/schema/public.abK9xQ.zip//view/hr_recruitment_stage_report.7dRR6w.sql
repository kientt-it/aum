create view hr_recruitment_stage_report
            (id, applicant_id, name, job_id, company_id, state, date_begin, date_end, days_in_stage, stage_id) as
SELECT row_number() OVER ()                                                                AS id,
       ha.id                                                                               AS applicant_id,
       ha.partner_name                                                                     AS name,
       ha.job_id,
       ha.company_id,
       CASE
           WHEN ha.active IS FALSE THEN 'refused'::text
           WHEN ha.date_closed IS NOT NULL THEN 'is_hired'::text
           ELSE 'in_progress'::text
           END                                                                             AS state,
       COALESCE(lag(mm.date) OVER (PARTITION BY mm.res_id ORDER BY mm.id), ha.create_date) AS date_begin,
       mm.date                                                                             AS date_end,
       date_part('epoch'::text,
                 mm.date - COALESCE(lag(mm.date) OVER (PARTITION BY mm.res_id ORDER BY mm.id), ha.create_date)) /
       (24 * 60 * 60)::numeric(16, 2)::double precision                                    AS days_in_stage,
       mtv.old_value_integer                                                               AS stage_id
FROM hr_applicant ha
         JOIN mail_message mm ON mm.res_id = ha.id AND mm.model::text = 'hr.applicant'::text
         JOIN mail_tracking_value mtv ON mtv.mail_message_id = mm.id
         JOIN ir_model_fields imf
              ON mtv.field = imf.id AND imf.model::text = 'hr.applicant'::text AND imf.name::text = 'stage_id'::text
UNION ALL
SELECT row_number() OVER ()                             AS id,
       ha.id                                            AS applicant_id,
       ha.partner_name                                  AS name,
       ha.job_id,
       ha.company_id,
       CASE
           WHEN ha.active IS FALSE THEN 'refused'::text
           WHEN ha.date_closed IS NOT NULL THEN 'is_hired'::text
           ELSE 'in_progress'::text
           END                                          AS state,
       COALESCE(md.date, ha.create_date)                AS date_begin,
       timezone('utc'::text, now())                     AS date_end,
       date_part('epoch'::text, timezone('utc'::text, now()) - COALESCE(md.date, ha.create_date)) /
       (24 * 60 * 60)::numeric(16, 2)::double precision AS days_in_stage,
       ha.stage_id
FROM hr_applicant ha
         JOIN hr_recruitment_stage hrs ON hrs.id = ha.stage_id
         LEFT JOIN LATERAL ( SELECT mm.date
                             FROM mail_message mm
                                      JOIN mail_tracking_value mtv ON mm.id = mtv.mail_message_id
                                      JOIN ir_model_fields imf
                                           ON mtv.field = imf.id AND imf.model::text = 'hr.applicant'::text AND
                                              imf.name::text = 'stage_id'::text
                             WHERE mm.res_id = ha.id
                               AND mm.model::text = 'hr.applicant'::text
                             ORDER BY mm.id DESC
                             LIMIT 1) md ON true
WHERE hrs.hired_stage IS NOT TRUE;

alter table hr_recruitment_stage_report
    owner to odoo_user;

