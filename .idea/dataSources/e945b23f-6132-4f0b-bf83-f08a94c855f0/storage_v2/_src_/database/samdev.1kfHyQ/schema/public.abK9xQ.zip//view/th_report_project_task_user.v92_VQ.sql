create view th_report_project_task_user
            (nbr, id, task_id, active, create_date, date_assign, date_end, date_last_stage_update, date_deadline,
             project_id, priority, name, company_id, partner_id, parent_id, ancestor_id, stage_id, is_closed, state,
             milestone_id, milestone_reached, milestone_deadline, rating_last_value, rating_avg, working_days_close,
             working_days_open, working_hours_open, working_hours_close, delay_endings_days)
as
SELECT (SELECT 1)                                       AS nbr,
       t.id,
       t.id                                             AS task_id,
       t.active,
       t.create_date,
       t.date_assign,
       t.date_end,
       t.date_last_stage_update,
       t.date_deadline_comp                             AS date_deadline,
       t.project_id,
       t.priority,
       t.name,
       t.company_id,
       t.partner_id,
       t.parent_id,
       t.ancestor_id,
       t.stage_id,
       t.is_closed,
       t.kanban_state                                   AS state,
       t.milestone_id,
       pm.is_reached                                    AS milestone_reached,
       pm.deadline                                      AS milestone_deadline,
       NULLIF(t.rating_last_value, 0::double precision) AS rating_last_value,
       avg(rt.rating)                                   AS rating_avg,
       t.working_days_close,
       t.working_days_open,
       t.working_hours_open,
       t.working_hours_close,
       date_part('epoch'::text, t.date_deadline_comp::timestamp without time zone - timezone('UTC'::text, now())) /
       (3600 * 24)::double precision                    AS delay_endings_days
FROM th_project_task t
         LEFT JOIN rating_rating rt
                   ON rt.res_id = t.id AND rt.res_model::text = 'th.project.task'::text AND rt.consumed = true AND
                      rt.rating >= 1::double precision
         LEFT JOIN th_project_milestone pm ON pm.id = t.milestone_id
WHERE t.project_id IS NOT NULL
GROUP BY t.id, t.active, t.create_date, t.date_assign, t.date_end, t.date_last_stage_update, t.date_deadline_comp,
         t.project_id, t.ancestor_id, t.priority, t.name, t.company_id, t.partner_id, t.parent_id, t.stage_id,
         t.is_closed, t.kanban_state, t.rating_last_value, t.working_days_close, t.working_days_open,
         t.working_hours_open, t.working_hours_close, t.milestone_id, pm.is_reached, pm.deadline;

alter table th_report_project_task_user
    owner to odoo_user;

