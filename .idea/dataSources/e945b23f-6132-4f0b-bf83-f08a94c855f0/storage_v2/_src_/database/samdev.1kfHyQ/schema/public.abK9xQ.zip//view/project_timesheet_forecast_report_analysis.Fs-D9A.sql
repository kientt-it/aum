create view project_timesheet_forecast_report_analysis
            (entry_date, employee_id, company_id, project_id, user_id, effective_hours, planned_hours, difference,
             line_type, id, is_published)
as
SELECT d.d::date                                                               AS entry_date,
       f.employee_id,
       f.company_id,
       f.project_id,
       f.user_id,
       0.0                                                                     AS effective_hours,
       f.allocated_hours / GREATEST(f.working_days_count, 1::double precision) AS planned_hours,
       f.allocated_hours / GREATEST(f.working_days_count, 1::double precision) AS difference,
       'forecast'::text                                                        AS line_type,
       f.id,
       CASE
           WHEN f.state::text = 'published'::text THEN true
           ELSE false
           END                                                                 AS is_published
FROM generate_series(((SELECT min(planning_slot.start_datetime) AS min
                       FROM planning_slot))::date::timestamp with time zone,
                     ((SELECT max(planning_slot.end_datetime) AS max
                       FROM planning_slot))::date::timestamp with time zone, '1 day'::interval) d(d)
         LEFT JOIN planning_slot f ON d.d::date >= f.start_datetime::date AND d.d::date <= f.end_datetime::date
         LEFT JOIN hr_employee e ON f.employee_id = e.id
UNION
SELECT a.date                                                                               AS entry_date,
       e.id                                                                                 AS employee_id,
       a.company_id,
       a.project_id,
       a.user_id,
       a.unit_amount / uom.factor::double precision * hour_uom.factor::double precision     AS effective_hours,
       0.0                                                                                  AS planned_hours,
       (- a.unit_amount) / uom.factor::double precision * hour_uom.factor::double precision AS difference,
       'timesheet'::text                                                                    AS line_type,
       - a.id                                                                               AS id,
       true                                                                                 AS is_published
FROM account_analytic_line a
         LEFT JOIN hr_employee e ON a.employee_id = e.id
         LEFT JOIN uom_uom uom ON a.product_uom_id = uom.id,
     (SELECT u.factor
      FROM uom_uom u
      WHERE u.id = 4) hour_uom
WHERE a.project_id IS NOT NULL;

alter table project_timesheet_forecast_report_analysis
    owner to odoo_user;

