create view im_livechat_report_channel
            (id, uuid, channel_id, channel_name, technical_name, livechat_channel_id, start_date, start_date_hour,
             start_hour, day_number, duration, time_to_answer, nbr_speaker, nbr_message, is_without_answer,
             days_of_activity, is_anonymous, country_id, is_happy, rating, rating_text, is_unrated, partner_id)
as
SELECT NULL::integer                     AS id,
       NULL::character varying(50)       AS uuid,
       NULL::integer                     AS channel_id,
       NULL::character varying           AS channel_name,
       NULL::text                        AS technical_name,
       NULL::integer                     AS livechat_channel_id,
       NULL::timestamp without time zone AS start_date,
       NULL::text                        AS start_date_hour,
       NULL::text                        AS start_hour,
       NULL::numeric                     AS day_number,
       NULL::numeric                     AS duration,
       NULL::numeric                     AS time_to_answer,
       NULL::bigint                      AS nbr_speaker,
       NULL::bigint                      AS nbr_message,
       NULL::integer                     AS is_without_answer,
       NULL::double precision            AS days_of_activity,
       NULL::integer                     AS is_anonymous,
       NULL::integer                     AS country_id,
       NULL::integer                     AS is_happy,
       NULL::double precision            AS rating,
       NULL::text                        AS rating_text,
       NULL::integer                     AS is_unrated,
       NULL::integer                     AS partner_id;

alter table im_livechat_report_channel
    owner to odoo_user;

