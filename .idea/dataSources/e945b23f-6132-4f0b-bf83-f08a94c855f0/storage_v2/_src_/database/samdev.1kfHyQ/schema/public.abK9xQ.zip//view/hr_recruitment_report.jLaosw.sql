create view hr_recruitment_report
            (id, user_id, count, create_date, create_uid, date_closed, stage_id, company_id, job_id, refuse_reason_id,
             medium_id, source_id, meetings_amount, state, name, refused, hired, hiring_ratio, process_duration)
as
SELECT a.id,
       a.user_id,
       1           AS count,
       a.create_date,
       a.create_uid,
       a.date_closed,
       a.stage_id,
       a.company_id,
       a.job_id,
       a.refuse_reason_id,
       a.medium_id,
       a.source_id,
       count(m.id) AS meetings_amount,
       CASE
           WHEN a.active IS FALSE THEN 'refused'::text
           WHEN a.date_closed IS NOT NULL THEN 'is_hired'::text
           ELSE 'in_progress'::text
           END     AS state,
       CASE
           WHEN a.partner_name IS NOT NULL THEN a.partner_name
           ELSE a.name
           END     AS name,
       CASE
           WHEN a.active IS FALSE THEN 1
           ELSE 0
           END     AS refused,
       CASE
           WHEN a.date_closed IS NOT NULL THEN 1
           ELSE 0
           END     AS hired,
       CASE
           WHEN a.date_closed IS NOT NULL THEN 100
           ELSE 0
           END     AS hiring_ratio,
       CASE
           WHEN a.date_closed IS NOT NULL THEN date_part('day'::text, a.date_closed - a.create_date)
           ELSE NULL::double precision
           END     AS process_duration
FROM hr_applicant a
         LEFT JOIN calendar_event m ON a.id = m.applicant_id
GROUP BY a.id;

alter table hr_recruitment_report
    owner to odoo_user;

