create view hr_work_entry_report
            (id, date_start, work_entry_type_id, employee_id, department_id, company_id, state, number_of_days,
             work_entry_source) as
SELECT we.id,
       we.date_start,
       we.work_entry_type_id,
       we.employee_id,
       we.department_id,
       we.company_id,
       we.state,
       we.duration / work_schedule.hours_per_day AS number_of_days,
       work_schedule.work_entry_source
FROM (SELECT hr_work_entry.id,
             hr_work_entry.employee_id,
             hr_work_entry.contract_id,
             hr_work_entry.date_start,
             hr_work_entry.date_stop,
             hr_work_entry.work_entry_type_id,
             hr_work_entry.department_id,
             hr_work_entry.company_id,
             hr_work_entry.state,
             hr_work_entry.duration
      FROM hr_work_entry
      WHERE hr_work_entry.employee_id IS NOT NULL
        AND (hr_work_entry.employee_id IN (SELECT hr_employee.id
                                           FROM hr_employee))
        AND hr_work_entry.active = true) we
         LEFT JOIN (SELECT contract.id AS contract_id,
                           contract.resource_calendar_id,
                           calendar.hours_per_day,
                           contract.work_entry_source
                    FROM hr_contract contract
                             LEFT JOIN (SELECT resource_calendar.id,
                                               resource_calendar.hours_per_day
                                        FROM resource_calendar) calendar
                                       ON calendar.id = contract.resource_calendar_id) work_schedule
                   ON we.contract_id = work_schedule.contract_id;

alter table hr_work_entry_report
    owner to odoo_user;

