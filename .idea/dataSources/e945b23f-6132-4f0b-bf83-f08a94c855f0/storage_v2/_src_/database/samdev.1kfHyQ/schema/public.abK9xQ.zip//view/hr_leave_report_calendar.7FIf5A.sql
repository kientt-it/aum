create view hr_leave_report_calendar
            (id, name, start_datetime, stop_datetime, employee_id, state, department_id, duration, company_id, job_id,
             tz, is_striked, is_hatched)
as
SELECT hl.id,
       concat(em.name, ': ', hl.duration_display)                                                             AS name,
       hl.date_from                                                                                           AS start_datetime,
       hl.date_to                                                                                             AS stop_datetime,
       hl.employee_id,
       hl.state,
       hl.department_id,
       hl.number_of_days                                                                                      AS duration,
       em.company_id,
       em.job_id,
       COALESCE(
               CASE
                   WHEN hl.holiday_type::text = 'employee'::text THEN COALESCE(rr.tz, rc.tz)
                   ELSE NULL::character varying
                   END, cc.tz, 'UTC'::character varying)                                                      AS tz,
       hl.state::text = 'refuse'::text                                                                        AS is_striked,
       hl.state::text <> ALL
       (ARRAY ['validate'::character varying::text, 'refuse'::character varying::text])                       AS is_hatched
FROM hr_leave hl
         LEFT JOIN hr_employee em ON em.id = hl.employee_id
         LEFT JOIN resource_resource rr ON rr.id = em.resource_id
         LEFT JOIN resource_calendar rc ON rc.id = em.resource_calendar_id
         LEFT JOIN res_company co ON co.id = em.company_id
         LEFT JOIN resource_calendar cc ON cc.id = co.resource_calendar_id
WHERE (hl.state::text = ANY
       (ARRAY ['confirm'::character varying::text, 'validate'::character varying::text, 'validate1'::character varying::text]))
  AND hl.active IS TRUE;

alter table hr_leave_report_calendar
    owner to odoo_user;

