create view hr_leave_employee_type_report
            (id, employee_id, active_employee, number_of_days, department_id, leave_type, holiday_status, state,
             date_from, date_to, company_id)
as
SELECT row_number() OVER (ORDER BY employee_id) AS id,
       employee_id,
       active_employee,
       number_of_days,
       department_id,
       leave_type,
       holiday_status,
       state,
       date_from,
       date_to,
       company_id
FROM (SELECT allocation.employee_id,
             employee.active                AS active_employee,
             CASE
                 WHEN request.number_of_days > 0::double precision
                     THEN allocation.number_of_days - request.number_of_days
                 ELSE allocation.number_of_days
                 END                        AS number_of_days,
             allocation.department_id,
             allocation.holiday_status_id   AS leave_type,
             allocation.state,
             allocation.date_from,
             allocation.date_to,
             'left'::text                   AS holiday_status,
             allocation.employee_company_id AS company_id
      FROM hr_leave_allocation allocation
               JOIN hr_employee employee ON allocation.employee_id = employee.id
               LEFT JOIN (SELECT hr_leave.holiday_status_id,
                                 hr_leave.employee_id,
                                 sum(hr_leave.number_of_days) AS number_of_days
                          FROM hr_leave
                          GROUP BY hr_leave.holiday_status_id, hr_leave.employee_id) request
                         ON allocation.employee_id = request.employee_id AND
                            allocation.holiday_status_id = request.holiday_status_id
      UNION ALL
      SELECT request.employee_id,
             employee.active             AS active_employee,
             request.number_of_days,
             request.department_id,
             request.holiday_status_id   AS leave_type,
             request.state,
             request.date_from,
             request.date_to,
             CASE
                 WHEN request.state::text = ANY
                      (ARRAY ['validate1'::character varying::text, 'validate'::character varying::text]) THEN 'taken'::text
                 WHEN request.state::text = 'confirm'::text THEN 'planned'::text
                 ELSE NULL::text
                 END                     AS holiday_status,
             request.employee_company_id AS company_id
      FROM hr_leave request
               JOIN hr_employee employee ON request.employee_id = employee.id) leaves;

alter table hr_leave_employee_type_report
    owner to odoo_user;

