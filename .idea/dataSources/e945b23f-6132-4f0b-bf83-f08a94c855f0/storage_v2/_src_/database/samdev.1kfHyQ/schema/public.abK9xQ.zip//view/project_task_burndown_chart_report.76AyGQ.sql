create view project_task_burndown_chart_report
            (id, project_id, task_id, display_project_id, stage_id, date, date_assign, date_deadline, partner_id,
             date_group_by, nb_tasks)
as
WITH all_moves_stage_task AS (SELECT pt.project_id,
                                     pt.id                    AS task_id,
                                     pt.display_project_id,
                                     COALESCE(lag(mm.date) OVER (PARTITION BY mm.res_id ORDER BY mm.id),
                                              pt.create_date) AS date_begin,
                                     mm.date                  AS date_end,
                                     mtv.old_value_integer    AS stage_id,
                                     pt.date_assign,
                                     pt.date_deadline,
                                     pt.partner_id
                              FROM project_task pt
                                       JOIN mail_message mm
                                            ON mm.res_id = pt.id AND mm.message_type::text = 'notification'::text AND
                                               mm.model::text = 'project.task'::text
                                       JOIN mail_tracking_value mtv ON mm.id = mtv.mail_message_id
                                       JOIN ir_model_fields imf
                                            ON mtv.field = imf.id AND imf.model::text = 'project.task'::text AND
                                               imf.name::text = 'stage_id'::text
                                       JOIN project_task_type_rel pttr
                                            ON pttr.type_id = mtv.old_value_integer AND pttr.project_id = pt.project_id
                              WHERE pt.active
                              UNION ALL
                              SELECT pt.project_id,
                                     pt.id                                    AS task_id,
                                     pt.display_project_id,
                                     COALESCE(md.date, pt.create_date)        AS date_begin,
                                     (CURRENT_DATE + '1 mon'::interval)::date AS date_end,
                                     pt.stage_id,
                                     pt.date_assign,
                                     pt.date_deadline,
                                     pt.partner_id
                              FROM project_task pt
                                       LEFT JOIN LATERAL ( SELECT mm.date
                                                           FROM mail_message mm
                                                                    JOIN mail_tracking_value mtv ON mm.id = mtv.mail_message_id
                                                                    JOIN ir_model_fields imf ON mtv.field = imf.id AND
                                                                                                imf.model::text =
                                                                                                'project.task'::text AND
                                                                                                imf.name::text =
                                                                                                'stage_id'::text
                                                           WHERE mm.res_id = pt.id
                                                             AND mm.message_type::text = 'notification'::text
                                                             AND mm.model::text = 'project.task'::text
                                                           ORDER BY mm.id DESC
                                                           LIMIT 1) md ON true
                              WHERE pt.active)
SELECT (t.task_id::double precision * (10::double precision ^ 7::double precision) +
        (10::double precision ^ 6::double precision) +
        to_char(d.d, 'YYMMDD'::text)::integer::double precision)::bigint AS id,
       t.project_id,
       t.task_id,
       t.display_project_id,
       t.stage_id,
       d.d                                                               AS date,
       t.date_assign,
       t.date_deadline,
       t.partner_id,
       'day'::text                                                       AS date_group_by,
       1                                                                 AS nb_tasks
FROM all_moves_stage_task t
         JOIN LATERAL generate_series(t.date_begin, t.date_end - '1 day'::interval, '1 day'::interval) d(d) ON true
UNION ALL
SELECT (t.task_id::double precision * (10::double precision ^ 7::double precision) +
        2::double precision * (10::double precision ^ 6::double precision) +
        to_char(d.d, 'YYMMDD'::text)::integer::double precision)::bigint AS id,
       t.project_id,
       t.task_id,
       t.display_project_id,
       t.stage_id,
       date_trunc('week'::text, d.d)                                     AS date,
       t.date_assign,
       t.date_deadline,
       t.partner_id,
       'week'::text                                                      AS date_group_by,
       1                                                                 AS nb_tasks
FROM all_moves_stage_task t
         JOIN LATERAL generate_series(t.date_begin, t.date_end, '7 days'::interval) d(d) ON true
WHERE date_trunc('week'::text, t.date_begin) <= date_trunc('week'::text, d.d)
  AND date_trunc('week'::text, t.date_end) > date_trunc('week'::text, d.d)
UNION ALL
SELECT (t.task_id::double precision * (10::double precision ^ 7::double precision) +
        3::double precision * (10::double precision ^ 6::double precision) +
        to_char(d.d, 'YYMMDD'::text)::integer::double precision)::bigint AS id,
       t.project_id,
       t.task_id,
       t.display_project_id,
       t.stage_id,
       date_trunc('month'::text, d.d)                                    AS date,
       t.date_assign,
       t.date_deadline,
       t.partner_id,
       'month'::text                                                     AS date_group_by,
       1                                                                 AS nb_tasks
FROM all_moves_stage_task t
         JOIN LATERAL generate_series(t.date_begin, t.date_end, '1 mon'::interval) d(d) ON true
WHERE date_trunc('month'::text, t.date_begin) <= date_trunc('month'::text, d.d)
  AND date_trunc('month'::text, t.date_end) > date_trunc('month'::text, d.d)
UNION ALL
SELECT (t.task_id::double precision * (10::double precision ^ 7::double precision) +
        4::double precision * (10::double precision ^ 6::double precision) +
        to_char(d.d, 'YYMMDD'::text)::integer::double precision)::bigint AS id,
       t.project_id,
       t.task_id,
       t.display_project_id,
       t.stage_id,
       date_trunc('quarter'::text, d.d)                                  AS date,
       t.date_assign,
       t.date_deadline,
       t.partner_id,
       'quarter'::text                                                   AS date_group_by,
       1                                                                 AS nb_tasks
FROM all_moves_stage_task t
         JOIN LATERAL generate_series(t.date_begin, t.date_end, '3 mons'::interval) d(d) ON true
WHERE date_trunc('quarter'::text, t.date_begin) <= date_trunc('quarter'::text, d.d)
  AND date_trunc('quarter'::text, t.date_end) > date_trunc('quarter'::text, d.d)
UNION ALL
SELECT (t.task_id::double precision * (10::double precision ^ 7::double precision) +
        5::double precision * (10::double precision ^ 6::double precision) +
        to_char(d.d, 'YYMMDD'::text)::integer::double precision)::bigint AS id,
       t.project_id,
       t.task_id,
       t.display_project_id,
       t.stage_id,
       date_trunc('year'::text, d.d)                                     AS date,
       t.date_assign,
       t.date_deadline,
       t.partner_id,
       'year'::text                                                      AS date_group_by,
       1                                                                 AS nb_tasks
FROM all_moves_stage_task t
         JOIN LATERAL generate_series(t.date_begin, t.date_end, '1 year'::interval) d(d) ON true
WHERE date_trunc('year'::text, t.date_begin) <= date_trunc('year'::text, d.d)
  AND date_trunc('year'::text, t.date_end) > date_trunc('year'::text, d.d);

alter table project_task_burndown_chart_report
    owner to odoo_user;

